<?php

namespace App\Http\Controllers;

use App\Models\CustomerProfile;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ProfileController extends Controller
{
    /**
     * Display the profile edit page.
     */
    public function edit(Request $request): View
    {
        $user    = $request->user();
        $profile = $request->user()->customerProfile;

        return view('profile.edit', [
            'user'              => $user,
            'profile'           => $profile,
            'paymentOptions'    => CustomerProfile::paymentOptions(),
            'deliveryOptions'   => CustomerProfile::deliveryOptions(),
            'frequencyOptions'  => CustomerProfile::frequencyOptions(),
            'orderValueOptions' => CustomerProfile::orderValueOptions(),
            'monthlyOptions'    => CustomerProfile::monthlyEstimateOptions(),
            'interestOptions'   => CustomerProfile::interestOptions(),
            'idTypeOptions'     => CustomerProfile::idTypeOptions(),
        ]);
    }

    /* ══════════════════════════════════════════════════
       TAB 1 — Account Info
    ══════════════════════════════════════════════════ */
    public function updateAccount(Request $request): RedirectResponse
    {
        $user = $request->user();

        $request->validate([
            'name'        => ['required', 'string', 'max:255'],
            'username'    => ['required', 'string', 'max:50',  Rule::unique('users')->ignore($user->id)],
            'email'       => ['required', 'string', 'lowercase', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
            'phone'       => ['required', 'string', 'max:15',  Rule::unique('users')->ignore($user->id)],
            'profile_pic' => ['nullable', 'image', 'mimes:jpeg,png,jpg,webp', 'max:2048'],
        ]);

        $user->name     = $request->name;
        $user->username = $request->username;
        $user->phone    = $request->phone;

        if ($user->email !== $request->email) {
            $user->email             = $request->email;
            $user->email_verified_at = null;
        }

        if ($request->hasFile('profile_pic')) {
            $file     = $request->file('profile_pic');
            $filename = 'avatar_' . $user->id . '_' . time() . '.' . $file->getClientOriginalExtension();
            $destDir  = public_path('storage/avatars');

            if (!file_exists($destDir)) mkdir($destDir, 0755, true);

            if ($user->profile_pic && file_exists(public_path('storage/' . $user->profile_pic))) {
                @unlink(public_path('storage/' . $user->profile_pic));
            }

            $file->move($destDir, $filename);
            $user->profile_pic = 'avatars/' . $filename;
        }

        $user->save();

        return Redirect::route('profile.edit')
            ->with('status', 'profile-updated')
            ->with('active_tab', 'account');
    }

    /* ══════════════════════════════════════════════════
       TAB 2 — Address
    ══════════════════════════════════════════════════ */
    public function updateAddress(Request $request): RedirectResponse
    {
        $request->validate([
            'address'     => ['required', 'string', 'max:500'],
            'zone'        => ['required', 'string', 'max:255'],
            'city'        => ['required', 'string', 'max:255'],
            'state'       => ['nullable', 'string', 'max:255'],
            'postal_code' => ['nullable', 'string', 'max:20'],
            'country'     => ['required', 'string', 'max:100'],
        ]);

        CustomerProfile::updateOrCreate(
            ['user_id' => $request->user()->id],
            [
                'address'     => $request->address,
                'zone'        => $request->zone,
                'city'        => $request->city,
                'state'       => $request->state,
                'postal_code' => $request->postal_code,
                'country'     => $request->country,
                'is_complete' => true,
            ]
        );

        return Redirect::route('profile.edit')
            ->with('status', 'profile-updated')
            ->with('active_tab', 'address');
    }

    /* ══════════════════════════════════════════════════
       TAB 3 — Shopping Preferences
    ══════════════════════════════════════════════════ */
    public function updatePreferences(Request $request): RedirectResponse
    {
        $request->validate([
            'preferred_payment'     => ['required', 'in:cod,card,wallet'],
            'delivery_preference'   => ['required', 'in:standard,fast'],
            'purchase_frequency'    => ['required', 'in:daily,weekly,monthly,rarely'],
            'avg_order_value'       => ['required', 'in:<50,50-200,200-500,500+'],
            'buyer_type'            => ['required', 'in:personal,business'],
            'monthly_estimate'      => ['required', 'in:<100,100-500,500-2000,2000+'],
            'interest_categories'   => ['nullable', 'array'],
            'interest_categories.*' => ['string'],
        ]);

        CustomerProfile::updateOrCreate(
            ['user_id' => $request->user()->id],
            [
                'preferred_payment'   => $request->preferred_payment,
                'delivery_preference' => $request->delivery_preference,
                'purchase_frequency'  => $request->purchase_frequency,
                'avg_order_value'     => $request->avg_order_value,
                'buyer_type'          => $request->buyer_type,
                'monthly_estimate'    => $request->monthly_estimate,
                'interest_categories' => $request->interest_categories ?? [],
                'is_complete'         => true,
            ]
        );

        return Redirect::route('profile.edit')
            ->with('status', 'profile-updated')
            ->with('active_tab', 'preferences');
    }

    /* ══════════════════════════════════════════════════
       TAB 4 — Security (password only)
    ══════════════════════════════════════════════════ */
    public function updatePassword(Request $request): RedirectResponse
    {
        $user = $request->user();

        $request->validate([
            'current_password' => ['required'],
            'new_password'     => ['required', 'min:8', 'confirmed'],
        ]);

        if (!Hash::check($request->current_password, $user->password)) {
            return back()
                ->withErrors(['current_password' => 'The current password you entered is incorrect.'])
                ->with('active_tab', 'security');
        }

        $user->password = Hash::make($request->new_password);
        $user->save();

        return Redirect::route('profile.edit')
            ->with('status', 'password-updated')
            ->with('active_tab', 'security');
    }

    /* ══════════════════════════════════════════════════
       Delete account
    ══════════════════════════════════════════════════ */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();
        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }
}