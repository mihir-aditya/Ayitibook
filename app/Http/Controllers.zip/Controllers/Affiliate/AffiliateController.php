<?php

namespace App\Http\Controllers\Affiliate;

use App\Http\Controllers\Controller;
use App\Models\Affiliate;
use App\Models\AffiliateLink;
use App\Models\AffiliateClick;
use App\Models\Commission;
use App\Services\AffiliateLinkService;
use App\Services\CommissionService;

use App\Http\Requests\CreateAffiliateLinkRequest;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class AffiliateController extends Controller
{
    protected AffiliateLinkService $linkService;
    protected CommissionService $commissionService;

    public function __construct(
        AffiliateLinkService $linkService,
        CommissionService $commissionService
    ) {
        $this->linkService = $linkService;
        $this->commissionService = $commissionService;
    }

    /**
     * Display a listing of all affiliates.
     */
    public function index()
    {
        $affiliates = Affiliate::with(['user', 'affiliateLinks', 'commissions'])
            ->paginate(15);

        return view('affiliate.index', compact('affiliates'));
    }

    /**
     * Show the form for creating a new affiliate.
     */
    public function create()
    {
        return view('affiliate.create');
    }

    /**
     * Store a newly created affiliate in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id'        => 'required|exists:users,id|unique:affiliates,user_id',
            'affiliate_code' => 'required|unique:affiliates',
            'status'         => 'required|in:active,suspended',
        ]);

        $affiliate = Affiliate::create($validated);

        if (auth('admin')->check()) {
            return redirect()->route('admin.affiliate.show', $affiliate->id)
                ->with('success', 'Affiliate created successfully');
        }

        return redirect()->route('affiliate.show', $affiliate->id)
            ->with('success', 'Affiliate created successfully');
    }

    /**
     * Display the specified affiliate.
     */
    public function show(Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);

        $affiliate->load(['user', 'affiliateLinks', 'commissions', 'affiliateClicks']);

        $totalEarnings       = $affiliate->commissions()->sum('amount');
        $totalClicks         = $affiliate->affiliateClicks()->count();
        $approvedCommissions = $affiliate->commissions()->where('status', 'approved')->count();

        return view('affiliate.show', compact('affiliate', 'totalEarnings', 'totalClicks', 'approvedCommissions'));
    }

    /**
     * Show the form for editing the specified affiliate.
     */
    public function edit(Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);
        return view('affiliate.edit', compact('affiliate'));
    }

    /**
     * Update the specified affiliate in storage.
     */
    public function update(Request $request, Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);

        $validated = $request->validate([
            'affiliate_code' => 'required|unique:affiliates,affiliate_code,' . $affiliate->id,
            'status'         => 'required|in:active,suspended',
            'total_earnings' => 'nullable|numeric|min:0',
        ]);

        $affiliate->update($validated);

        if (auth('admin')->check()) {
            return redirect()->route('admin.affiliate.show', $affiliate->id)
                ->with('success', 'Affiliate updated successfully');
        }

        return redirect()->route('affiliate.show', $affiliate->id)
            ->with('success', 'Affiliate updated successfully');
    }

    /**
     * Remove the specified affiliate from storage.
     */
    public function destroy(Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);
        $affiliate->delete();

        if (auth('admin')->check()) {
            return redirect()->route('admin.affiliate.index')
                ->with('success', 'Affiliate deleted successfully');
        }

        return redirect()->route('affiliate.index')
            ->with('success', 'Affiliate deleted successfully');
    }

    /**
     * Get affiliate links for the given affiliate.
     * Also passes $products so the "Add New Link" modal on the links page works inline.
     */
    public function getLinks(Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);

        $links    = $affiliate->affiliateLinks()->with('product')->paginate(10);
        $products = \App\Models\Product::query()->orderBy('name')->get();

        return view('affiliate.links', compact('affiliate', 'links', 'products'));
    }

    /**
     * Show form to create a new affiliate link for an affiliate.
     */
    public function createLink(Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);

        $products = \App\Models\Product::query()->orderBy('name')->get();

        return view('affiliate.create_link', compact('affiliate', 'products'));
    }

    /**
     * Store a newly created affiliate link.
     * affiliate_id comes from the route — do NOT include it in the form/request.
     */
    public function storeLink(CreateAffiliateLinkRequest $request, Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);

        $data = $request->validated();

        $link = $this->linkService->createAffiliateLink(
            $affiliate->id,
            (int) $data['product_id'],
            $data['link_code'] ?? null
        );

        return redirect()->route('affiliate.links', $affiliate->affiliate_code)
            ->with('success', 'Link created! Your code: ' . $link->link_code);
    }

    /**
     * Ensure current user owns the affiliate (simple ownership check).
     */
    protected function authorizeOwner(Affiliate $affiliate): void
    {
        // Allow admins (admin guard) to bypass ownership checks
        if (auth('admin')->check()) {
            return;
        }

        if (!auth()->check() || auth()->id() !== $affiliate->user_id) {
            abort(403);
        }
    }

    /**
     * Get commission details for the given affiliate.
     */
    public function getCommissions(Affiliate $affiliate)
    {
        $commissions = $affiliate->commissions()
            ->with(['order', 'customer'])
            ->paginate(15);

        $totalCommissions   = $affiliate->commissions()->sum('amount');
        $pendingCommissions = $affiliate->commissions()
            ->where('status', 'pending')
            ->sum('amount');

        return view('affiliate.commissions', compact('affiliate', 'commissions', 'totalCommissions', 'pendingCommissions'));
    }

    /**
     * Get click analytics for the given affiliate.
     */
    public function getClicks(Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);

        $clicks = $affiliate->affiliateClicks()
            ->with(['affiliateLink', 'customer'])
            ->paginate(20);

        $totalClicks    = $this->linkService->getTotalClicks($affiliate->id);
        $conversionRate = $this->linkService->getConversionRate($affiliate->id);

        return view('affiliate.clicks', compact('affiliate', 'clicks', 'totalClicks', 'conversionRate'));
    }

    /**
     * Get affiliate dashboard/statistics.
     */
    public function dashboard(Affiliate $affiliate)
    {
        $this->authorizeOwner($affiliate);

        $totalEarnings   = $affiliate->commissions()->sum('amount');
        $monthlyEarnings = $affiliate->commissions()
            ->where('status', 'paid')
            ->whereYear('created_at', now()->year)
            ->whereMonth('created_at', now()->month)
            ->sum('amount');

        $totalClicks         = $affiliate->affiliateClicks()->count();
        $totalLinks          = $affiliate->affiliateLinks()->count();
        $approvedCommissions = $affiliate->commissions()
            ->where('status', 'approved')
            ->count();

        $recentCommissions = $affiliate->commissions()
            ->latest()
            ->limit(5)
            ->get();

        return view('affiliate.dashboard', compact(
            'affiliate',
            'totalEarnings',
            'monthlyEarnings',
            'totalClicks',
            'totalLinks',
            'approvedCommissions',
            'recentCommissions'
        ));
    }

    /**
     * Get products being tracked by affiliates (admin view).
     */
    public function trackedProducts()
    {
        $trackedProducts = \App\Models\Product::query()
            ->with(['affiliateLinks.affiliate.user', 'affiliateLinks' => function ($query) {
                $query->withCount('affiliateClicks');
            }])
            ->whereHas('affiliateLinks')
            ->withCount(['affiliateLinks as total_links'])
            ->withCount(['affiliateLinks as total_clicks' => function ($query) {
                $query->join('affiliate_clicks', 'affiliate_links.id', '=', 'affiliate_clicks.affiliate_link_id')
                      ->selectRaw('count(*)');
            }])
            ->paginate(15);

        return view('admin.affiliate.tracked-products', compact('trackedProducts'));
    }

    /**
     * Approve a commission.
     */
    public function approveCommission(Commission $commission)
    {
        $commission->update(['status' => 'approved']);

        return redirect()->back()->with('success', 'Commission approved successfully');
    }

    /**
     * Reject a commission.
     */
    public function rejectCommission(Commission $commission)
    {
        $commission->update(['status' => 'rejected']);

        return redirect()->back()->with('success', 'Commission rejected successfully');
    }

    /**
     * Mark a commission as paid.
     */
    public function payCommission(Commission $commission)
    {
        $commission->update(['status' => 'paid']);

        return redirect()->back()->with('success', 'Commission marked as paid successfully');
    }

    /**
     * Bulk approve commissions.
     */
    public function bulkApproveCommissions(Request $request)
    {
        $commissionIds = $request->input('commission_ids', []);

        Commission::whereIn('id', $commissionIds)->update(['status' => 'approved']);

        return redirect()->back()
            ->with('success', count($commissionIds) . ' commissions approved successfully');
    }

    /**
     * Bulk update affiliate status.
     */
    public function bulkStatusUpdate(Request $request)
    {
        $affiliateIds = $request->input('affiliate_ids', []);
        $status       = $request->input('status');

        Affiliate::whereIn('id', $affiliateIds)->update(['status' => $status]);

        return redirect()->back()
            ->with('success', count($affiliateIds) . ' affiliates updated successfully');
    }
    public function destroyLink(Affiliate $affiliate, AffiliateLink $link)
{
    $this->authorizeOwner($affiliate);
    $link->delete();
    return redirect()->route('affiliate.links', $affiliate->affiliate_code)
        ->with('success', 'Link deleted successfully');
}
}