<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    // ──────────────────────────────────────────────
    // GET /products
    // ──────────────────────────────────────────────
    public function index(Request $request)
    {
        $search  = $request->get('q');
        $perPage = (int) $request->get('per_page', 9);

        $products = Product::whereNull('deleted_at')
            ->where('is_active', true)
            ->search($search)           // uses the scopeSearch() from the model
            ->with(['category', 'brand'])
            ->latest()
            ->paginate($perPage)
            ->withQueryString();

        if ($request->wantsJson()) {
            return response()->json($products);
        }

        return view('pages.search-product', compact('products', 'search'));
    }

    // ──────────────────────────────────────────────
    // GET /products/{product}
    // ──────────────────────────────────────────────
    public function show(Product $product)
    {
        // 404 if soft-deleted or not active
        abort_if(
            $product->trashed() || ! $product->is_active,
            404
        );

        // Eager-load all relationships needed by the view
        $product->load([
            'seller',
            'reviews.user', 
            'category',
            'brand',
            'variants',          // ProductVariant collection
        ]);

        // ── Related products: same category, excluding current ──
        $relatedProducts = Product::whereNull('deleted_at')
            ->where('is_active', true)
            ->where('id', '!=', $product->id)
            ->when($product->category_id, fn ($q) => $q->where('category_id', $product->category_id))
            ->with(['category'])
            ->inRandomOrder()
            ->limit(8)
            ->get();
            $product->load([]);

        return view('pages.product-details', compact('product', 'relatedProducts'));
    }
}